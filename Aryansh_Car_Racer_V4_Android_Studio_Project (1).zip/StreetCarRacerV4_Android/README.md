# Aryansh Car Racer — Android Studio Project

Game name changed to **Aryansh Car Racer**.

V4 features:
- Garage
- Sport, GT and Hyper cars
- Performance upgrades
- Nitro
- Traffic
- Coins
- Rain, fog, clear and night weather
- Police chase
- Touch controls

Build:
1. Open this folder in Android Studio.
2. Sync Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
